# React-Inventory-Management-System
Inventory Management System Built with React JS, Node JS, Express JS, MongoDB and Tailwind CSS.

Step 1: Open terminal go to project folder of backend folder
Step 2: npm install
Step 3: npm start
Step 4: Open another terminal go to frontend folder
Step 5: npm install
Step 6: npm start

Username: nitinshelake101@gmail.com
Password: nitin@12345